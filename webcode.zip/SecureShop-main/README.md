# SecureShop

SecureShop is a customizable e-commerce web application source-code project.

## Important: source-code package

This package does **not** include a live database, production credentials, hosting, or a guarantee that every feature is production-ready. Before using it commercially, configure and test your own services, database policies, authentication, payments (if applicable), and deployment.

## Requirements

- Node.js version compatible with the project dependencies
- npm
- A Supabase project for features that use Supabase

Check `package.json` for the project's scripts and dependency versions.

## Setup

1. Download or clone the project.
2. Install dependencies:

   ```bash
   npm install
   ```

3. Copy `.env.example` to `.env` and fill in values from your **own** Supabase project.
4. Start the development server using the appropriate script listed in `package.json` (commonly `npm run dev`).

## Environment variables

- `VITE_SUPABASE_URL`: Supabase project URL used by the browser.
- `VITE_SUPABASE_PUBLISHABLE_KEY`: Supabase publishable/anon key used by the browser.
- `SUPABASE_URL`: Supabase project URL for server-side code.
- `SUPABASE_SERVICE_ROLE_KEY`: Supabase service-role secret for trusted server-side operations only.

**Never put `SUPABASE_SERVICE_ROLE_KEY` in a `VITE_` variable or expose it in browser/client code.** The service-role key can bypass Row Level Security (RLS). Store it only in server-side environment settings and configure strict database policies.

## Before production

- Create and review Supabase RLS policies for every exposed table.
- Test authorization and admin access on the server, not only in the UI.
- Configure your own hosting, domain, and environment variables.
- Review any integrations and replace demo/sample content.
- Run security and functional tests before accepting real customer data or payments.

## Scope

This repository is provided as source code for customization. Database setup, third-party services, hosting, credentials, and production hardening must be configured by the buyer unless separately agreed in writing.
