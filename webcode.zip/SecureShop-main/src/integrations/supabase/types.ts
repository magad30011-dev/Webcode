﻿export type Database = any
